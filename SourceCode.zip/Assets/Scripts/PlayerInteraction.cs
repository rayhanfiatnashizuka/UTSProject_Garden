using UnityEngine;

public class PlayerInteraction : MonoBehaviour
{
    public int cropsCollected = 0;

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Crop"))
        {
            CollectCrop(other.gameObject);
        }
        else if (other.CompareTag("Animal"))
        {
            Animal a = other.GetComponent<Animal>();
            if (a != null)
            {
                Debug.Log(a.sound);
            }
        }
    }

    void CollectCrop(GameObject crop)
    {
        cropsCollected++;
        Debug.Log("Crop harvested: " + cropsCollected);
        Destroy(crop);
    }
}
