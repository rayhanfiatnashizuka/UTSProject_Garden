using UnityEngine;

public class MonsterAttack : MonoBehaviour
{
    public Animator animator;              
    public float attackCooldown = 1f;

    private bool playerInRange = false;
    private float cooldownTimer = 0f;

    private PlayerMovement playerMovement; 

    private void Start()
    {
        GameObject p = GameObject.FindWithTag("Player");
        if (p != null)
        {
            playerMovement = p.GetComponent<PlayerMovement>();
        }
    }

    private void Update()
    {
        cooldownTimer -= Time.deltaTime;

        animator.SetBool("playerNear", playerInRange);

        if (playerInRange && cooldownTimer <= 0f)
        {
            AttackPlayer();
        }
    }

    void AttackPlayer()
    {
        cooldownTimer = attackCooldown;

        animator.SetTrigger("attack");

        Debug.Log("Monster attacks!");

        if (playerMovement != null)
        {
            playerMovement.ApplyDamage(transform.position);
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            playerInRange = true;
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            playerInRange = false;
        }
    }
}
