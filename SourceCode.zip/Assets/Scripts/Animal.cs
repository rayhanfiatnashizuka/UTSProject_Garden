using UnityEngine;

public class Animal : MonoBehaviour
{
    [Tooltip("The sound this animal makes")]
    public string sound = "MOO";  
}
