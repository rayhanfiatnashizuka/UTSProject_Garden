using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerMovement : MonoBehaviour
{
    public float moveSpeed = 5f;
    private Vector2 movement;

    public Rigidbody2D rb;
    public Animator animator;
    public Transform visual;

    public Vector2 minBounds;
    public Vector2 maxBounds;

    public float hurtDuration = 0.4f;
    public float recoilStrength = 6f;
    private bool isHurt = false;

    void Update()
    {
        if (isHurt) return;

        movement = Vector2.zero;
        if (Keyboard.current.wKey.isPressed) movement.y = 1;
        if (Keyboard.current.sKey.isPressed) movement.y = -1;
        if (Keyboard.current.aKey.isPressed) movement.x = -1;
        if (Keyboard.current.dKey.isPressed) movement.x = 1;
        movement = movement.normalized;

        animator.SetBool("isMoving", movement.sqrMagnitude > 0.01f);

        if (movement.x < 0) visual.localScale = new Vector3(-1, 1, 1);
        else if (movement.x > 0) visual.localScale = Vector3.one;
    }

    void FixedUpdate()
    {
        if (isHurt) return;

        Vector2 newPos = rb.position + movement * moveSpeed * Time.fixedDeltaTime;

        newPos.x = Mathf.Clamp(newPos.x, minBounds.x, maxBounds.x);
        newPos.y = Mathf.Clamp(newPos.y, minBounds.y, maxBounds.y);

        rb.MovePosition(newPos);
    }

    public void ApplyDamage(Vector2 attackerPos)
    {
        if (isHurt) return;

        isHurt = true;
        animator.SetTrigger("Hurt");
        Debug.Log("Player is hurt!");

        Vector2 dir = (rb.position - attackerPos).normalized;
        if (dir == Vector2.zero) dir = Vector2.up;

        rb.linearVelocity = dir * recoilStrength;

        Invoke(nameof(ResetHurt), hurtDuration);
    }

    void ResetHurt()
    {
        isHurt = false;
        rb.linearVelocity = Vector2.zero;
    }
}
